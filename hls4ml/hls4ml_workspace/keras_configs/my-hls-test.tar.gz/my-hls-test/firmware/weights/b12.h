//Numpy array shape [5]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 5

#ifndef B12_H_
#define B12_H_

#ifndef __SYNTHESIS__
Dense_bias_t b12[5];
#else
Dense_bias_t b12[5] = {0.00000000000000000000, 0.00000000000000000000, 0.00000000000000000000, 0.00000000000000000000, 0.00000000000000000000};
#endif

#endif
