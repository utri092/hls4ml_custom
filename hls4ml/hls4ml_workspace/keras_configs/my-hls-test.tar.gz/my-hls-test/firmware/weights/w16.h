//Numpy array shape [5, 1]
//Min -0.501368284225
//Max -0.046913385391
//Number of zeros 0

#ifndef W16_H_
#define W16_H_

#ifndef __SYNTHESIS__
Dense_weight_t w16[5];
#else
Dense_weight_t w16[5] = {-0.04691338539123535156, -0.37571454048156738281, -0.50136828422546386719, -0.31904506683349609375, -0.48594856262207031250};
#endif

#endif
