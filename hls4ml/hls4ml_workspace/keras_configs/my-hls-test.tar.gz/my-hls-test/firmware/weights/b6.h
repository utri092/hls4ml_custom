//Numpy array shape [5]
//Min -0.096294112504
//Max 0.190990343690
//Number of zeros 1

#ifndef B6_H_
#define B6_H_

#ifndef __SYNTHESIS__
Dense_bias_t b6[5];
#else
Dense_bias_t b6[5] = {0.19099034368991851807, -0.03230129554867744446, 0.00000000000000000000, 0.17733891308307647705, -0.09629411250352859497};
#endif

#endif
