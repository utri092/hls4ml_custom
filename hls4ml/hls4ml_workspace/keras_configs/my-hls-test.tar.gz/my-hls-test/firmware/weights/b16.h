//Numpy array shape [1]
//Min 20.635997772217
//Max 20.635997772217
//Number of zeros 0

#ifndef B16_H_
#define B16_H_

#ifndef __SYNTHESIS__
Dense_bias_t b16[1];
#else
Dense_bias_t b16[1] = {20.63599777221679687500};
#endif

#endif
