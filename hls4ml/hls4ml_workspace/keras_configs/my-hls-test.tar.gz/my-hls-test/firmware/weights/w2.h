//Numpy array shape [2, 2]
//Min -0.884019255638
//Max -0.015509366989
//Number of zeros 0

#ifndef W2_H_
#define W2_H_

#ifndef __SYNTHESIS__
Dense_weight_t w2[4];
#else
Dense_weight_t w2[4] = {-0.19428431987762451172, -0.01550936698913574219, -0.88401925563812255859, -0.01972711086273193359};
#endif

#endif
