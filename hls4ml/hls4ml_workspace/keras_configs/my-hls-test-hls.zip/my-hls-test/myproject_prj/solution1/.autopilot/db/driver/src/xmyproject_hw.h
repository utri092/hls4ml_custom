// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2020.1 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// model_interface
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read)
//        bit 7  - auto_restart (Read/Write)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0  - Channel 0 (ap_done)
//        bit 1  - Channel 1 (ap_ready)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0  - Channel 0 (ap_done)
//        bit 1  - Channel 1 (ap_ready)
//        others - reserved
// 0x10 : Data signal of input1_V
//        bit 31~0 - input1_V[31:0] (Read/Write)
// 0x14 : Data signal of input1_V
//        bit 31~0 - input1_V[63:32] (Read/Write)
// 0x18 : Data signal of input1_V
//        bit 31~0 - input1_V[95:64] (Read/Write)
// 0x1c : Data signal of input1_V
//        bit 31~0 - input1_V[127:96] (Read/Write)
// 0x20 : reserved
// 0x24 : Data signal of layer10_out_0_V
//        bit 31~0 - layer10_out_0_V[31:0] (Read)
// 0x28 : Data signal of layer10_out_0_V
//        bit 31~0 - layer10_out_0_V[63:32] (Read)
// 0x2c : Control signal of layer10_out_0_V
//        bit 0  - layer10_out_0_V_ap_vld (Read/COR)
//        others - reserved
// 0x30 : Data signal of const_size_in_1
//        bit 15~0 - const_size_in_1[15:0] (Read)
//        others   - reserved
// 0x34 : Control signal of const_size_in_1
//        bit 0  - const_size_in_1_ap_vld (Read/COR)
//        others - reserved
// 0x38 : Data signal of const_size_out_1
//        bit 15~0 - const_size_out_1[15:0] (Read)
//        others   - reserved
// 0x3c : Control signal of const_size_out_1
//        bit 0  - const_size_out_1_ap_vld (Read/COR)
//        others - reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XMYPROJECT_MODEL_INTERFACE_ADDR_AP_CTRL               0x00
#define XMYPROJECT_MODEL_INTERFACE_ADDR_GIE                   0x04
#define XMYPROJECT_MODEL_INTERFACE_ADDR_IER                   0x08
#define XMYPROJECT_MODEL_INTERFACE_ADDR_ISR                   0x0c
#define XMYPROJECT_MODEL_INTERFACE_ADDR_INPUT1_V_DATA         0x10
#define XMYPROJECT_MODEL_INTERFACE_BITS_INPUT1_V_DATA         128
#define XMYPROJECT_MODEL_INTERFACE_ADDR_LAYER10_OUT_0_V_DATA  0x24
#define XMYPROJECT_MODEL_INTERFACE_BITS_LAYER10_OUT_0_V_DATA  64
#define XMYPROJECT_MODEL_INTERFACE_ADDR_LAYER10_OUT_0_V_CTRL  0x2c
#define XMYPROJECT_MODEL_INTERFACE_ADDR_CONST_SIZE_IN_1_DATA  0x30
#define XMYPROJECT_MODEL_INTERFACE_BITS_CONST_SIZE_IN_1_DATA  16
#define XMYPROJECT_MODEL_INTERFACE_ADDR_CONST_SIZE_IN_1_CTRL  0x34
#define XMYPROJECT_MODEL_INTERFACE_ADDR_CONST_SIZE_OUT_1_DATA 0x38
#define XMYPROJECT_MODEL_INTERFACE_BITS_CONST_SIZE_OUT_1_DATA 16
#define XMYPROJECT_MODEL_INTERFACE_ADDR_CONST_SIZE_OUT_1_CTRL 0x3c

