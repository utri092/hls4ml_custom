// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2020.1 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================

extern void AESL_WRAP_myproject (
ap_fixed<64, 32, (ap_q_mode) 5, (ap_o_mode)3, 0> input1[2],
ap_fixed<64, 32, (ap_q_mode) 5, (ap_o_mode)3, 0> layer10_out[1],
unsigned short (&const_size_in_1),
unsigned short (&const_size_out_1));
