//Numpy array shape [2, 2]
//Min -0.587812781334
//Max 1.223182082176
//Number of zeros 0

#ifndef W2_H_
#define W2_H_

#ifndef __SYNTHESIS__
Dense_weight_t w2[4];
#else
Dense_weight_t w2[4] = {0.13595207035541534424, -0.58781278133392333984, 0.27071222662925720215, 1.22318208217620849609};
#endif

#endif
