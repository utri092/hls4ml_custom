//Numpy array shape [1]
//Min 0.103566035628
//Max 0.103566035628
//Number of zeros 0

#ifndef B10_H_
#define B10_H_

#ifndef __SYNTHESIS__
Dense_bias_t b10[1];
#else
Dense_bias_t b10[1] = {0.10356603562831878662};
#endif

#endif
