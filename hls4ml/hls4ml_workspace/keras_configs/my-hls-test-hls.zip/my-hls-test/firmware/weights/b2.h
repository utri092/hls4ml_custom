//Numpy array shape [2]
//Min -0.061372101307
//Max 0.000000000000
//Number of zeros 1

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
Dense_bias_t b2[2];
#else
Dense_bias_t b2[2] = {-0.06137210130691528320, 0.00000000000000000000};
#endif

#endif
