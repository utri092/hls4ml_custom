//Numpy array shape [5]
//Min -0.064556874335
//Max 0.000000000000
//Number of zeros 4

#ifndef B4_H_
#define B4_H_

#ifndef __SYNTHESIS__
Dense_bias_t b4[5];
#else
Dense_bias_t b4[5] = {-0.06455687433481216431, 0.00000000000000000000, 0.00000000000000000000, 0.00000000000000000000, 0.00000000000000000000};
#endif

#endif
