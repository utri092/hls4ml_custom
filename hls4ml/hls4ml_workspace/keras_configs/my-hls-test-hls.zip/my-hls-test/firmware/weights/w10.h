//Numpy array shape [5, 1]
//Min -0.733664453030
//Max 0.687372624874
//Number of zeros 0

#ifndef W10_H_
#define W10_H_

#ifndef __SYNTHESIS__
Dense_weight_t w10[5];
#else
Dense_weight_t w10[5] = {-0.73366445302963256836, -0.00667881965637207031, 0.58814883232116699219, 0.55399894714355468750, 0.68737262487411499023};
#endif

#endif
