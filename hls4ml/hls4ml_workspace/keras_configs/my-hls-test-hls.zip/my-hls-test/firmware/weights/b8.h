//Numpy array shape [5]
//Min -0.100383386016
//Max 0.108299031854
//Number of zeros 3

#ifndef B8_H_
#define B8_H_

#ifndef __SYNTHESIS__
Dense_bias_t b8[5];
#else
Dense_bias_t b8[5] = {-0.10038338601589202881, 0.00000000000000000000, 0.00000000000000000000, 0.00000000000000000000, 0.10829903185367584229};
#endif

#endif
